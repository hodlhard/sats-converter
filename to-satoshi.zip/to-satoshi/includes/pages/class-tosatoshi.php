<?php
/**
 * Handles ajax
 */

namespace MpToSatoshi\Includes\Pages;

use DateTime;
use MongoDB\Driver\Query;
use MpToSatoshi\Includes\Db\MyDb;
use MpToSatoshi\Includes\Db\PereereDb\Db;
use MpToSatoshi\Includes\Db\PereereDb\PrGreaterThan;
use MpToSatoshi\Includes\Db\PereereDb\PrLimits;
use MpToSatoshi\Includes\Db\PereereDb\PrNotEqualTo;
use MpToSatoshi\Includes\Db\PereereDb\PrOrderBy;
use MpToSatoshi\Includes\Db\PereereDb\PrOrderByAsc;
use MpToSatoshi\Includes\Db\PereereDb\PrOrderByDesc;
use MpToSatoshi\Includes\Db\PereereDb\PrWhereIn;
use MpToSatoshi\Includes\Db\PereereDb\PrWhereNot;
use MpToSatoshi\Includes\Db\PereereDb\QueryBuilder;
use MpToSatoshi\Includes\Libs\Common;
use MpToSatoshi\Includes\Libs\Email;
use MpToSatoshi\Includes\Libs\Options;
use MpToSatoshi\Includes\Libs\Start;
use MpToSatoshi\Includes\Pages\Interfaces\Page;
use PhpOffice\PhpSpreadsheet\Exception;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;


/**
 * JustToWin Processing class
 *
 * @author MACHINE PEREERE Contact: mpereere@gmail.com
 * Created on : Feb 26, 2019, 1:25:50 PM
 */
class ToSatoshi {


	/**
	 * Holds this class instatnce
	 *
	 * @var null
	 */
	private static $instance = null;

	/**
	 * ToSatoshi constructor.
	 */
	public function __construct() {

	}


	/**
	 * Sets hooks
	 *
	 * @return mixed|void
	 */
	public function set_hooks() {
		add_action( 'mp_tosatoshi_ajax_save_css', [ $this, 'ajax_save_css' ], 10, 1 );
	}

	/**
	 * Save css
	 *
	 * @param $post
	 */
	public function ajax_save_css( $post ) {

		Common::verify_post( $post );
		$the_css = $post[ Common::VAR_2 ]['the_css'];
		$all_css = $post[Common::VAR_2];
		update_option( 'tosatoshi_css', $the_css );
		update_option( 'tosatoshi_all_css', $all_css );


		Common::send_success( "Success!!! Saved.", [] );
	}

	/**
	 * Return instance
	 *
	 * @return \MpToSatoshi\Includes\Pages\ToSatoshi
	 */
	public static function get_instance() {
		if ( self::$instance == null ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

}