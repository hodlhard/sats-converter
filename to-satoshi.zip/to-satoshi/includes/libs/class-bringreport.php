<?php

namespace MpToSatoshi\Includes\Libs;

/**
 * BringReport Processing class
 *
 * @author MACHINE PEREERE Contact: mpereere@gmail.com
 * Created on : Feb 26, 2020, 1:25:50 PM
 */
class BringReport {

	/**
	 * BringReport constructor.
	 */
	public function __construct() {
		add_filter( 'mp_wr_submit_form', [ $this, 'submit_form_senter' ], 1 );
	}

	/**
	 * Loads center pop up template
	 *
	 * @param string $button_text Text to display on button
	 * @param string $button_text_progress Text to display on button while loading
	 */
	public static function response_html_center( $button_text, $button_text_progress = "" ) {
		$html = '
      <hr style="color:white; background: white;" />
      <div class="mp-alert w3-card mp-form-control mp-width-100-perc ">
        <div class="resp_one_two" style="text-align:center">
          <div class="mp-alert mp-btn-success none login-report-success none" ></div>
          <div class="mp-alert mp-btn-danger none login-report-failure none" ></div>
          <div class="mp-progress hose_484_prog " style="display:none">
            <div class="mp-progress-bar mp-btn-success mp-progress-bar-animated mp-progress-bar-striped hose_839_main_prog" ></div>
          </div>
          <br />
          <button class="mp-btn mp-btn-success mp_submit "   type="submit">
            <span class="mp_input_spinner_whiteParent mp_submit_spinner none ">
              <span class="mp_input_spinner_white fa fa-spinner fa-spin"  rel="tooltip"  ></span>
            </span>
            <span class="mp-response-show-start-text">' . $button_text . '</span>
            <span class="mp-response-show-progress-text none">' . $button_text_progress . '</span>
          </button>
        </div>
      </div>
            ';
		echo $html;
	}

	/**
	 * Loads pop up template
	 */
	public static function response_html_popup() {
		$html = ' <hr style="color:white; background: white;" />
      <div class="alert w3-card form-control">
        <div id="mp-response-pupup-parent">
          <div class="alert btn-success none login-report-success none" ></div>
          <div class="alert btn-danger none login-report-failure none" ></div>
          <div class="progress hose_484_prog " style="display:none">
            <div class="progress-bar btn-success progress-bar-animated progress-bar-striped hose_839_main_prog" ></div>
          </div><br />
          <button class="w3-card form-control margin-auto mp_submit "  style="    padding: 10px 40px;"  type="submit">
            <span class="mp_input_spinner_whiteParent mp_submit_spinner none ">
              <span class="mp_input_spinner_white fa fa-spinner fa-spin"  rel="tooltip"  ></span>
            </span>
            <span class="mp-response-show-start-text">Done</span>
            <span class="mp-response-show-progress-text none">Processing..</span>
          </button>
        </div>
      </div>
            ';
		echo $html;
	}

}
