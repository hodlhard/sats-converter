<?php
/**
 * Initializes Hooks and enquere screepts and does other things
 *
 * @class   Start
 * @package Betting Tips
 */

namespace MpToSatoshi\Includes\Libs;

use MpToSatoshi\Includes\Db\MyDb;
use MpToSatoshi\Includes\Pages\Count;
use MpToSatoshi\Includes\Pages\Create;
use MpToSatoshi\Includes\Pages\Generate;
use MpToSatoshi\Includes\Pages\JustToWin;
use MpToSatoshi\Includes\Pages\Medical;
use MpToSatoshi\Includes\Pages\Preview;
use MpToSatoshi\Includes\Pages\Settings;
use MpToSatoshi\Includes\Pages\Test;
use MpToSatoshi\Includes\Pages\ToSatoshi;
use MpToSatoshi\Includes\Pages\WidgetOne;
use MpToSatoshi\Includes\Widgets\Widget1;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Start Processing class
 *
 * @author MACHINE PEREERE Contact: mpereere@gmail.com
 * Created on : Dec 26, 2019, 1:25:50 PM
 */
class Start {

	/**
	 * Holds localize
	 *
	 * @var array
	 */
	public static $all_localize = [];
	/**
	 * Holds this class instance
	 *
	 * @var $instance ToSatoshi
	 */
	private static $instance;
	/**
	 * Holds Total for display
	 *
	 * @var string
	 */
	public static $total = '';

	/**
	 * Gets this class instance
	 *
	 * @return \MpToSatoshi\Includes\Libs\Start|\MpToSatoshi\Includes\Pages\ToSatoshi
	 */
	public static function get_instance() {
		if ( self::$instance === null ) {
			self::$instance = new Start();
		}

		return self::$instance;
	}

	/**
	 * Start constructor.
	 */
	public function __construct() {
		new Common();
		$this->set_hooks();
	}

	/**
	 * Set some hooks
	 */
	private function set_hooks() {
		add_action( 'init', [ $this, 'hook_init' ] );
		add_action( "init", [ $this, 'init' ] );
		add_action( 'admin_menu', [ $this, "hook_admin_menu" ], 1 );
		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_user' ] );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_admin' ] );
	}

	/**
	 * Initialize all
	 */
	function init() {
		if ( ( ! wp_doing_ajax() ) && ( ! is_admin() ) ) {
			$this->do_shortcodes();
		}
	}

	/**
	 * Prepare all shortcodes
	 */
	public function do_shortcodes() {
		add_shortcode( 'bitcoin_satoshi_converter', array( $this, 'shortcode_bitcoin_satoshi_converter' ) );
	}

	/**
	 * Satoshi template
	 *
	 * @return string
	 */
	public function shortcode_bitcoin_satoshi_converter() {
		wp_enqueue_style( 'tosatoshi_css' );
		$exchange = json_decode( file_get_contents( 'https://min-api.cryptocompare.com/data/price?fsym=BTC&tsyms=USD,JPY,EUR,GBP&api_key=eea59cb230ca125d012965506e39e979eb048a2d5a77d2bc72849a36395b39eb' ), true );

		if ( is_array( $exchange ) ) {
			$all_css = get_option( 'tosatoshi_all_css' );
			if ( is_array( $all_css ) ) {
				$currency = $all_css['target_currency'];
				$caption  = 'USD';
				$rate     = (float) $exchange['USD'];
				if ( $currency === 'g' ) {
					$caption = 'GBP';
					$rate    = (float) $exchange['GBP'];
				} elseif ( $currency === 'e' ) {
					$caption = 'EUR';
					$rate    = (float) $exchange['EUR'];
				} elseif ( $currency === 'j' ) {
					$caption = 'JPY';
					$rate    = (float) $exchange['JPY'];
				}
				//let total  = (1 / rate) * 100000000;
				//    this.total = `1 ${caption} buys
				//    <b>${total.toFixed(2).replace(/\d(?=(\d{3})+\.)/g, "$&,")}</b> Satoshis`;
				$total          = ( 1 / $rate ) * 100000000;
				$money_formated = number_format( $total, 0 );
				$final_total    = " 1 $caption buys <b>$money_formated</b> Satoshis";
				self::$total    = $final_total;
			} else {
				self::$total = 'Satoshi to USD API Error: Settings Not saved yet';
			}
			wp_add_inline_style( 'tosatoshi_css', str_replace( array( "\r", "\n" ), '', get_option( 'tosatoshi_css' ) ) );
			$file_name = Common::$plugin_dir . '/templates/shortcodes/tosatoshi.php';

			return Common::getContents( $file_name );
		}

		return 'Satoshi to USD API Error';

	}

	/**
	 * Initialize admin menu
	 */
	public function hook_admin_menu() {
		add_menu_page(
			'Satoshi to USD',
			'Satoshi to USD',
			'manage_options',
			'satoshi-to-usd',
			[
				$this,
				'menu_build',
			],
			'dashicons-admin-site-alt3'
		);
	}

	/**
	 * Build the menu
	 */
	public function menu_build() {
		require_once Common::$plugin_dir . '/templates/admin/controller.php';
	}

	/**
	 * Gets ajax url
	 *
	 * @return string
	 */
	public static function get_ajax_url() {
		return get_admin_url( 'admin.js' ) . "admin-ajax.php";;
	}

	/**
	 * Sets ajax action
	 */
	public static function set_ajax_action() {
		$ajax_url    = get_admin_url( 'admin.js' ) . "admin-ajax.php";
		$ajax_action = "ajax_mp_tosatoshi";

		$all                   = [];
		$all['ajax_url']       = $ajax_url;
		$all['ajax_action']    = $ajax_action;
		$all['admin_page_now'] = 1;

		Start::$all_localize = array_merge( $all, self::$all_localize );
	}

	/**
	 * Gets ajax actions
	 *
	 * @return array
	 */
	public static function get_ajax_action() {
		$ajax_url    = get_admin_url( 'admin.js' ) . "admin-ajax.php";
		$ajax_action = "ajax_mp_tosatoshi";

		$all                   = [];
		$all['ajax_url']       = $ajax_url;
		$all['ajax_action']    = $ajax_action;
		$all['admin_page_now'] = 1;

		return $all;
	}

	/**
	 * Enqueu admin
	 */
	public function enqueue_admin() {

		$in_one_of_them = false;
		$all_parts      = [
			'justtowin',
		];
		$page           = filter_input( INPUT_GET, 'page' );
		if ( ! ( $page && ( $page === 'satoshi-to-usd' ) ) ) {
			return false;
		}
		$base             = "mp-justtowin";
		$dist_css_static  = get_site_url() . '/wp-content/plugins/' . Common::$plugin_name . '/assets/dist-css/static';
		$dist_css_current = get_site_url() . '/wp-content/plugins/' . Common::$plugin_name . '/assets/dist-css/current';
		$extra_css        = get_site_url() . '/wp-content/plugins/' . Common::$plugin_name . '/assets/extra-css';
		$extra_js         = get_site_url() . '/wp-content/plugins/' . Common::$plugin_name . '/assets/extra-js';
		$ahost            = "http://localhost/ahost";

		/** Styles */
		$css_font_awesome = $ahost . '/fa/css/font-awesome.min.css';
		$css_animated_css = $ahost . '/animated.css';
		$css_w3_css       = $ahost . '/w3css.css';
		$css_bootstrap    = $ahost . '/boot5/dist/css/bootstrap.min.css';
		$css_mboots       = $dist_css_static . '/css_boots.css';
		$css_common       = $dist_css_static . '/common.css';
		$css_general      = $dist_css_static . '/general.css';
		$css_flat_pick    = $dist_css_static . '/foo-pick.css';
		$css_foo_pick     = $dist_css_static . '/flat-pick.css';
		if ( Common::$online_now ) {
			$css_font_awesome = 'https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css';
			$css_w3_css       = 'https://www.w3schools.com/lib/w3.css';
			$css_bootstrap    = 'https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css';
		}
		/** Scripts */
		$js_ckeditor        = 'https://cdn.ckeditor.com/ckeditor5/16.0.0/classic/ckeditor.js';
		$js_jquery          = 'https://code.jquery.com/jquery-3.4.1.min.js';
		$js_bootstrap_js    = 'https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js';
		$js_vue             = 'https://cdn.jsdelivr.net/npm/vue/dist/vue.js';
		$js_vuex            = 'https://unpkg.com/vuex@3.1.2/dist/vuex.js';
		$js_es6_promise     = 'https://cdn.jsdelivr.net/npm/es6-promise@4/dist/es6-promise.auto.js';
		$js_flat_pick       = $extra_js . '/flat-pick.js';
		$js_foo_pick        = $extra_js . '/foo-pick.js';
		$js_moment          = 'https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.24.0/moment.min.js';
		$js_datetime_picker = 'https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/js/bootstrap-datetimepicker.min.js';
		if ( Common::$online_now === false ) {
			//			$js_vue = $ahost . "/vuejs-dev.js";
		}

		/** General styles */
		wp_enqueue_style( $base . 'fontawesome', $css_font_awesome, [], 1 );
		wp_enqueue_style( $base . 'animated', $css_animated_css, [], 1 );
		wp_enqueue_style( $base . 'w3css', $css_w3_css, [], 1 );
		wp_enqueue_style( $base . 'bootstrap', $css_bootstrap, [], 1 );
		wp_enqueue_style( $base . 'mboots', $css_mboots, [], Common::$script_version );
		wp_enqueue_style( $base . 'common', $css_common, [], Common::$script_version );
		wp_enqueue_style( $base . 'general', $css_general, [], Common::$script_version );
		/** General scripts */
		wp_enqueue_script( $base . 'jquery', $js_jquery, [], 1, true );
		wp_enqueue_script( $base . 'vue', $js_vue, [], 1, true );
		wp_enqueue_script( $base . 'vuex', $js_vuex, [], 1, true );
		wp_enqueue_script( $base . 'es6promise', $js_es6_promise, [], 1, true );
		wp_enqueue_script( $base . 'bootstrapjs', $js_bootstrap_js, [], 1, true );
		wp_enqueue_script( $base . 'moment', $js_moment, [], 1, true );

		/** For pages */

		$this->prepare_localize_variables();
		$admin_js  = get_site_url() . '/wp-content/plugins/' . Common::$plugin_name . '/assets/dist/tosatoshi.js';
		$admin_css = get_site_url() . '/wp-content/plugins/' . Common::$plugin_name . '/assets/dist-css/current/tosatoshi.css';
		wp_enqueue_script( 'tosatoshi_admin', $admin_js, [], Common::$script_version, true );
		wp_enqueue_style( 'tosatoshi_admin_css', $admin_css, [], Common::$script_version );
		wp_localize_script( 'tosatoshi_admin', 'mpereere_local_tosatoshi', [ self::$all_localize ] );
		//others
		wp_enqueue_script( $base . 'moment', 'https://cdn.jsdelivr.net/momentjs/latest/moment.min.js', [], 1 );
	}

	/**
	 * Prepare localize variables
	 */
	public function prepare_localize_variables() {
		self::set_ajax_action();
		$all_css = get_option( 'tosatoshi_all_css' );
		if ( ! $all_css ) {
			$all_css = [
				'background_color'    => "#ffffff",
				'background_type'     => "solid",
				'border_color'        => "#c0c0c0",
				'border_corner_style' => "rounded",
				'border_width'        => "3",
				'font_color'          => "#000000",
				'font_family'         => "Verdana",
				'font_size'           => "medium",
				'target_currency'     => "e",
				'the_css'             => "      .satoshi111 {        background-color : #ffffff;        border : 3px solid #c0c0c0 !important;        border-color : #c0c0c0 !important;        border-bottom-left-radius : 10px !important;        border-bottom-right-radius : 10px !important;        border-top-left-radius : 10px !important;        border-top-right-radius : 10px !important;      }            .satoshifont {          font-size : 15px !important;          color : #000000 !important;          font-family : Verdana;        }    ",
			];
		}
		Start::$all_localize = array_merge( [
			'rate' => json_decode( file_get_contents( 'https://min-api.cryptocompare.com/data/price?fsym=BTC&tsyms=USD,JPY,EUR,GBP&api_key=eea59cb230ca125d012965506e39e979eb048a2d5a77d2bc72849a36395b39eb' ), true ),
			'all'  => array(
				'nonce'   => wp_create_nonce( Common::$nonce_key ),
				'all_css' => $all_css,
			),
		], self::$all_localize );
	}

	/**
	 * Prepare localize variables for users
	 */
	public
	function prepare_localize_variables_user() {
		self::set_ajax_action();
	}


	/**
	 * Enqueue users styles
	 */
	public
	function enqueue_user() {
		$dist_css_current = get_site_url() . '/wp-content/plugins/' . Common::$plugin_name . '/assets/dist-css/current';
		$css_tosatoshi    = $dist_css_current . '/tosatoshi.css';
		wp_register_style( 'tosatoshi_css', $css_tosatoshi, [], Common::$script_version );
	}

	/**
	 * Hooks on initialize
	 */
	public
	function hook_init() {
		//    echo "setting";

		$ajax_admin = "ajax_mp_tosatoshi";
		$prefix     = "wp_ajax_";
		add_action( $prefix . $ajax_admin, [ $this, 'switch_recieved_ajax' ] );
		$prefix = "wp_ajax_nopriv_";
		$fff    = $prefix . $ajax_admin;
		//    echo $fff;
		add_action( $fff, [ $this, 'switch_recieved_ajax' ] );
	}

	/**
	 * On ajax received
	 */
	public
	function switch_recieved_ajax() {

		$post = Common::get_post();
		ToSatoshi::get_instance()->set_hooks();
		$action = sanitize_title( $post[ Common::VAR_0 ] );
		do_action( $action, $post );

		die( 'null Justtowin plugin' );
	}

}
