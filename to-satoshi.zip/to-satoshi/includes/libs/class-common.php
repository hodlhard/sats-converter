<?php
/**
 * Medical Plugin. Common functions.
 *
 * @class   Common
 * @package MpToSatoshi/Includes/Libs
 */

namespace MpToSatoshi\Includes\Libs;

use MpToSatoshi\Includes\Db\MyDb;
use MpToSatoshi\Includes\Pages\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Common Processing class
 *
 * @author MACHINE PEREERE Contact: mpereere@gmail.com
 * Created on : Dec 26, 2019, 1:25:50 PM
 */
class Common {

	/**
	 * Holds true when on line
	 *
	 * @var array
	 */
	public static $online_now = false;
	/**
	 * Holds plugin name
	 *
	 * @var string
	 */
	public static $plugin_name = "";
	/**
	 * Holds Default Plugin Directory
	 *
	 * @var string
	 */
	public static $plugin_dir = '';
	/**
	 * Holds image directory
	 *
	 * @var string
	 */
	public static $images_dir = '';
	/**
	 * Holds plugin url
	 *
	 * @var string
	 */
	public static $plugin_url = "";
	/**
	 * Holds key to nonce
	 *
	 * @var string
	 */
	public static $nonce_key = "tosatoshi";
	/**
	 * Holds current plugin version
	 *
	 * @var float
	 */
	public static $script_version = 1.0;
	/**
	 * Holds true while in development
	 *
	 * @var bool
	 */
	public static $in_development = true;
	/**
	 * Holds this class instance
	 *
	 * @var null | \MpToSatoshi\Includes\Libs\Common
	 */
	private static $instance = null;
	/**
	 * Holds the variable 0 of an ajax request
	 */
	const VAR_0 = "var_0";
	/**
	 * Holds the variable 1 of an ajax request
	 */
	const VAR_1 = "var_1";
	/**
	 * Holds the variable 2 of an ajax request
	 */
	const VAR_2 = "var_2";
	/**
	 * Key for ajax action
	 *
	 * @var string
	 */
	static $s_f_what = "what";
	/**
	 * Key for ajax data
	 *
	 * @var string
	 */
	static $s_f_data = "data";
	/**
	 * Key for ajax message response
	 *
	 * @var string
	 */
	static $s_f_message = "message";
	/**
	 * Key for ajax status
	 *
	 * @var string
	 */
	static $s_f_status = "status";
	/**
	 * Value for ajax success response
	 *
	 * @var string
	 */
	static $s_f_success = "0";
	/**
	 * Value for ajax error response
	 *
	 * @var string
	 */
	static $s_f_failure = "1";
	/**
	 * Value for ajax critical error response
	 *
	 * @var string
	 */
	static $s_f_error = "2";

	/**
	 * Common constructor.
	 */
	function __construct() {
		if ( ! $_SERVER["SERVER_NAME"] === "localhost" ) {
			self::$online_now = true;
		}

		$this->init_constants();
	}

	/**
	 * GetContents Obstart & Loads file & Obclean
	 *
	 * @param string $filename The file name.
	 *
	 * @return string file content
	 */
	public static function getContents( $filename ) {
		ob_start();
		require $filename;
		$code = ob_get_clean();
		//		$code = ob_get_contents();
		//		ob_end_clean();
		return $code;
	}

	/**
	 * Returns this class instance
	 *
	 * @return \MpToSatoshi\Includes\Libs\Common|null
	 */
	public static function get_instance() {
		if ( self::$instance === null ) {
			self::$instance = new Common();
		}

		return self::$instance;
	}

	/**
	 * Verifies Post requests using nonce
	 *
	 * @param $post
	 */
	public static function verify_post( $post ) {
		if ( ! ( isset( $post[ Common::VAR_1 ] ) ) ) {
			Common::send_failure( 'Unknown Request' );
		}
		$nonce = $post[ Common::VAR_1 ];
		if ( ! wp_verify_nonce( $nonce, self::$nonce_key ) ) {
			Common::send_failure( 'Error. Please reload page.' );
		}
	}

	/**
	 * Initializes some variables
	 */
	private function init_constants() {
		self::$plugin_name = 'to-satoshi';
		self::$plugin_dir  = ABSPATH . "wp-content/plugins/" . self::$plugin_name;
		self::$images_dir  = get_site_url() . "/wp-content/plugins/" . self::$plugin_name . '/assets/images';
		self::$plugin_url  = get_site_url() . "/wp-content/plugins/" . self::$plugin_name;
		if ( self::$in_development ) {
			self::$script_version = time();
		}

		add_action( 'mp_wr_good', [ $this, 'send_good' ], 10, 2 );
		add_action( 'mp_wr_bad', [ $this, 'send_bad' ], 10, 2 );
	}

	/**
	 * Reads request from Post from ajax
	 *
	 * @return mixed
	 */
	public static function get_post() {
		$data = json_decode( trim( preg_replace( '/\\\"/', "\"",
			$_POST["form_data"] ) ), true );
		if ( $data == null ) {
			$data = json_decode( stripslashes( $_POST["form_data"] ), true );
		}

		return $data['data'];
	}

	public static function send_success( $message, $data = [] ) {
		self::send_out_statis( self::$s_f_success, $data, $message );
	}

	public static function send_failure( $message, $data = [] ) {
		//    self::sendOut(self::$S_F_FAILURE, $string);
		//    add_action('mp_wr_bad', [$this, 'send_bad'], 10, 2);
		self::send_out_statis( self::$s_f_failure, $data, $message );
	}

	/**
	 * Sends success ajax response
	 *
	 * @param $data
	 * @param $message
	 */
	public function send_good( $data, $message ) {
		// var_dump(['start',$data]);
		$arr                       = [];
		$arr[ self::$s_f_status ]  = self::$s_f_success;
		$arr[ self::$s_f_data ]    = $data;
		$arr[ self::$s_f_message ] = $message;
		echo( json_encode( $arr ) );
		die;
	}

	/**
	 * Sends unsuccessful ajax response
	 *
	 * @param $data
	 * @param $message
	 */
	public function send_bad( $data, $message ) {
		// var_dump(['start',$data]);
		$arr                       = [];
		$arr[ self::$s_f_status ]  = self::$s_f_failure;
		$arr[ self::$s_f_data ]    = $data;
		$arr[ self::$s_f_message ] = $message;
		echo( json_encode( $arr ) );
		die;
	}

	/**
	 * Sends out static response
	 *
	 * @param $status
	 * @param $data
	 * @param $message
	 */
	public static function send_out_statis( $status, $data, $message ) {
		// var_dump(['start',$data]);
		$arr                       = [];
		$arr[ self::$s_f_status ]  = $status;
		$arr[ self::$s_f_data ]    = $data;
		$arr[ self::$s_f_message ] = $message;
		echo( json_encode( $arr ) );
		die;
	}

	/**
	 * Starts the process of sending out request
	 *
	 * @param $status
	 * @param $data
	 * @param $message
	 */
	public function sendOut( $status, $data, $message ) {
		// var_dump(['start',$data]);
		$arr                       = [];
		$arr[ self::$s_f_status ]  = $status;
		$arr[ self::$s_f_data ]    = $data;
		$arr[ self::$s_f_message ] = $message;
		echo( json_encode( $arr ) );
		die;
	}

	/**
	 * @param int $days e.g. -1 for yesterday or +1 for tomorrow
	 *
	 * @return false|string
	 */
	public static function getDateTime( $days = 0 ) {
		$date = date( 'Y-m-d H:i:s' );
		if ( $days !== 0 ) {
			$days = "$days days";
			$date = date( 'Y-m-d H:i:s', strtotime( $days ) );
		}

		return $date;

	}



}
