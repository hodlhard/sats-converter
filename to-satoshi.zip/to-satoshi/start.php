<?php
/**
 * Takes care of autoload
 *
 * @package MpToSatoshi
 */

use MpToSatoshi\Includes\Libs\Start;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
try {
	spl_autoload_register(
		function ( $name ) {
			$class = explode( '\\', $name );

			$path  = plugin_dir_path( __FILE__ );
			$path2 = plugin_dir_path( __FILE__ );
			foreach ( $class as $key => $value ) {
				if ( 0 === $key ) {
					continue;
				}
				if ( ( count( $class ) - 1 ) === $key ) {
					$path  .= 'class-' . strtolower( $value ) . '/';
					$path2 .= 'interface-' . strtolower( $value ) . '/';
				} else {
					$path  .= strtolower( $value ) . '/';
					$path2 .= strtolower( $value ) . '/';
				}
			}
			$path  = trim( $path, '/' ) . '.php';
			$path2 = trim( $path2, '/' ) . '.php';
//			var_dump(
//				"<pre>",
//				[
//					"path"         => $path,
//					"path 2 "      => $path2,
//					"path exists " => file_exists( "/" . $path ),
//				],
//				"</pre>"
//			);
			if ( file_exists( $path ) ) {
				require_once $path;
			} elseif ( file_exists( $path2 ) ) {
				require_once $path2;
			} elseif ( file_exists( "/" . $path ) ) {
				require_once "/" . $path;
			} elseif ( file_exists( "/" . $path2 ) ) {
				require_once "/" . $path2;
			}
		}
	);
} catch ( Exception $e ) {
}






