/* Add your custom javascript codes here for the front page */

var fjieosi = 0;

let intfeifeifj = setInterval(function () {
  try{
    if (fjieosi > 100) {
      clearInterval(intfeifeifj);
    }
    if( document.getElementById('site_preloader') !== null){
      document.getElementById('site_preloader').style.display = 'none';
    }

  }catch (e) {
    
  }
  fjieosi++;
}, 1000);