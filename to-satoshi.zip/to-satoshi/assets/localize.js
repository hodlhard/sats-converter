try{
  // Silence is golden
}catch (e) {

}