<?php
/**
 * Admin page template
 */

use MpToSatoshi\Includes\Libs\BringReport;
use MpToSatoshi\Includes\Libs\Common;

$icon = Common::$plugin_url . '/assets/images/logo.png';
?>
<div class="">
	<div class="container-fluid animated zoomIn" xmlns:v-on="http://www.w3.org/1999/xhtml" xmlns:v-bind="http://www.w3.org/1999/xhtml">
		<div class="row builder-area">
			<div class="alert">Use the following shortcode on your site to embed the Satoshi calculator anywhere you want <code>[bitcoin_satoshi_converter]</code></div>
			<div class="col-12 row wrap">
				<div class="col-12 header">
					<label>Base Currency
						<select>
							<option>Satoshi</option>
						</select>
					</label>
					<label>Target Currency
						<select v-model="css.target_currency" class="option">
							<option value="u">USD</option>
							<option value="g">GBP</option>
							<option value="e">EUR</option>
							<option value="j">JPY</option>
						</select>
					</label>
				</div>
				<form v-on:submit.prevent="xhrSaveSatoshi()" id="tosatoshi-css-save" class="col-12 row body-area">
					<?php /** Background Area */ ?>
					<div class="col-12 row background-area">
						<div class="col-12 col-md-4 color-choose-parent">
							<p class="label-title">Background Color</p>
							<input v-model="css.background_color" class="color-choose" type="color">
						</div>
						<div class="col-12 col-md-8 toggle-solid">
							<p class="label-title">Transparent Background</p>
							<div class="transparent-solid">
								<div @click="setSolidOrTransparent('transparent')" :class="{active : css.background_type === 'transparent','not-active' : css.background_type === 'solid' }" class=" transparent">Transparent</div>
								<div @click="setSolidOrTransparent('solid')" :class="{active : css.background_type === 'solid','not-active' : css.background_type === 'transparent' }" class=" solid">Solid</div>
							</div>
						</div>
					</div>
					<?php /** Border Area */ ?>
					<div class="col-12 row border-area" style="margin-left: 0;">
						<div class="col-12 col-md-4 input-area-special">
							<p class="label-title">Border Width</p>
							<div class="number-wrap">
								<input v-model="css.border_width" type="number">
								<span>px</span>
							</div>
						</div>
						<div class="col-12 col-md-8 row border-color-and-style">
							<div class="col-12 col-md-4 color-choose-parent">
								<p class="label-title">Border Color</p>
								<input v-model="css.border_color" class="color-choose" value="1" type="color">
							</div>
							<div class="col-12 col-md-8 color-choose-parent">
								<p class="label-title">Corner Style</p>
								<select v-model="css.border_corner_style">
									<option value="rounded">Rounded</option>
									<option value="square">Square</option>
								</select>
							</div>
						</div>
					</div>
					<?php /** Font Area */ ?>
					<div class="col-12 row border-area" style="margin-left: 0;">
						<div class="col-12 col-md-4 input-area-special">
							<p class="label-title">Font Size</p>
							<div class="number-wrap">
								<select v-model="css.font_size">
									<option value="small">Small</option>
									<option value="medium">Medium</option>
									<option value="large">Large</option>
								</select>
							</div>
						</div>
						<div class="col-12 col-md-8 row border-color-and-style">
							<div class="col-12 col-md-4 color-choose-parent">
								<p class="label-title">Font Color</p>
								<input v-model="css.font_color" class="color-choose" value="1" type="color">
							</div>
							<div class="col-12 col-md-8 color-choose-parent">
								<p class="label-title">Font Family</p>
								<select v-model="css.font_family">
									<option value="Arial">Arial</option>
									<option value="serif">Serif</option>
									<option value="san-serif">San Serif</option>
									<option value="Verdana">Verdana</option>
								</select>
							</div>
						</div>
					</div>
					<?php /** Preview */ ?>
					<div class="col-12 preview-area" style="margin-left: 0;">
						<h3 class="text-center" style="margin-top: 30px;"><i class="fa fa-search"></i> &nbsp; Preview</h3>
						<div class="wrap satoshi111" :style="getCssObj()">
							<p class="head-title satoshifont" v-html="total"></p>
							<div class="line"></div>
							<div class="bottom" style="margin: auto !important;">
								<p class="powered">
									Powered By:
								</p>
								<div class="icon-and-name">
									<a href="https://hodlhard.io"><img src="<?php echo $icon; ?>" alt=""> HodlHard.io</a>
								</div>
							</div>
						</div>
					</div>
					<?php BringReport::response_html_center( 'Save', 'Saving...' ); ?>
				</form>
			</div>
		</div>
	</div>
</div>
