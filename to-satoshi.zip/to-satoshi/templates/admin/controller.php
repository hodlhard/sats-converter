<?php
/**
 * Introduces the begining file
 */
defined( 'ABSPATH' ) || exit;

use MpToSatoshi\Includes\Libs\Common;

/**
 * Class AdminController
 */
class AdminController {

	/**
	 * AdminController constructor.
	 */
	public function __construct() {
		require_once Common::$plugin_dir . '/templates/admin/begin.php';
	}

}

new AdminController();

