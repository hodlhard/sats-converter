<?php
/**
 * Loads admin menu and files
 */

use MpToSatoshi\Includes\Libs\BringReport;
use MpToSatoshi\Includes\Libs\Common;

$pages    = array(
	'Satoshi To USD',
);
$pages_js = array(
	'',
	'',
);
?>
<div data-hide="mp-parent-root" style="background-color: #eee;">
	<div id="tosatoshi" v-cloak xmlns:v-bind="http://www.w3.org/1999/xhtml" xmlns:v-on="http://www.w3.org/1999/xhtml">
		<div class="nav-tab-wrapper-manuser" style="margin-bottom: 5px;">
			<div class="front-nav" style="">
				<div class="wrap-links">
					<?php foreach ( $pages as $key => $one_page ): ?>
						<b v-bind:class="{'nav-active' : page === <?php echo( $key + 1 ); ?>}"
								v-on:click="change_page(<?php echo( $key + 1 ) ?>)">
							<?php echo $one_page; ?><?php echo ' ' . $pages_js[ $key ] ?>
						</b>
					<?php endforeach; ?>
				</div>
			</div>
		</div>
		<?php foreach ( $pages as $key => $one_page ): ?>
			<div v-if='page === <?php echo( $key + 1 ); ?>'>
				<?php require_once Common::$plugin_dir . '/templates/admin/' . str_replace( ' ', '-', strtolower( $one_page ) ) . '.php'; ?>
			</div>
		<?php endforeach; ?>
		<button class="mp-wr-reset-button-01" style="display: none;" v-on:click='something_clicked()'>Click Me</button>
		<input style="display: none;" type="text" v-if='something_value'>
	</div>
	<div class="mpereere-vue-loading"><i class="fa fa-spin fa-spinner"></i>
		<p>Loading...</p>
	</div>
	<?php /** Progress */ ?>
</div>
<div class="w3-modal hide_mgbe" id="mp-response-modal" style="text-align: center; z-index: 999999; ">
	<div class="w3-card-4 alert w3-animate-zoom " style="background: white; max-width: 400px; margin: 0 auto;">
		<div style="display:flex;">
			<span style="flex: 8"></span>
			<button id="delete_id_close" class="btn btn-outline-secondary close_times_yy mp-response-modal-close"> Close
				<i class=" fa fa-times" style=""></i>
			</button>
		</div>
		<div class=""><?php BringReport::response_html_popup(); ?>
		</div>
	</div>
</div>