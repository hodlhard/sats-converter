<?php
/**
 * Shortcode template file
 */
use MpToSatoshi\Includes\Libs\Common;
use MpToSatoshi\Includes\Libs\Start;

$icon = Common::$plugin_url . '/assets/images/logo.png';
?>
<div class="total">
	<div class="col-12 preview-area" style="margin-left: 0;">
		<div class="wrap satoshi111">
			<p class="head-title satoshifont"><?php echo Start::$total; ?></p>
			<div class="line"></div>
			<div class="bottom">
				<p class="powered">
					Powered By:
				</p>
				<div class="icon-and-name">
					<a href="https://hodlhard.io"><img src="<?php echo $icon; ?>" alt=""> HodlHard.io</a>
				</div>
			</div>
		</div>
	</div>
</div>