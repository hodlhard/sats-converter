<?php
/**
 * Plugin Start File
 *
 * @package  MpToSatoshi
 * @version  2.6.0
 */



if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
/**
 * Plugin Description
 *
 * @link              https://hodlhard.io
 * @since             1.0.0
 * @package           MpToSatoshi
 *
 * @wordpress-plugin
 * Plugin Name:       Bitcoin Satoshi to USD converter
 * Plugin URI:        https://hodlhard.io
 * Description:       Converts satoshi to USD, JPY, GBP, EUR
 * Version:           1.0.0
 * Author:            Hodlhard.io
 * Author URI:        https://hodlhard.io
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 */


require_once 'start.php';

use MpToSatoshi\Includes\Libs\Start;

$start = Start::get_instance();

$namespace = 'MpToSatoshi';